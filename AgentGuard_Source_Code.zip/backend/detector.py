import re
from typing import Any, Dict, List, Optional, Tuple


# Regex patterns and signature definitions for prompt injection and malicious payload detection
SUSPICIOUS_PATTERNS = [
    (
        r"ignore\s+(all\s+)?(previous|prior|above)\s+(instructions|prompts|rules|commands)",
        "Instruction override / jailbreak attempt ('ignore previous instructions')",
        "HIGH",
    ),
    (
        r"(disregard|forget|bypass|override)\s+(all\s+)?(system|safety|security|prior)\s+(instructions|prompts|rules|guards)",
        "Safety guard bypass attempt",
        "HIGH",
    ),
    (
        r"(reveal|print|show|output|leak|exfiltrate|display|dump)\s+(the\s+)?(system\s+prompt|initial\s+prompt|developer\s+mode|secret|api[_\s\-]?key|token|password|credential)",
        "System prompt extraction or secret exfiltration attempt",
        "HIGH",
    ),
    (
        r"bypass\s+security|disable\s+security|ignore\s+safety|disable\s+guardrails|unrestricted\s+mode",
        "Direct security barrier disable attempt",
        "HIGH",
    ),
    (
        r"you\s+are\s+now\s+(in\s+)?(dan|developer\s+mode|unrestricted|god\s+mode|an\s+evil\s+ai|jailbroken)",
        "Persona hijacking / DAN jailbreak attempt",
        "HIGH",
    ),
    (
        r"execute\s+(this\s+)?(shell|bash|command|script|powershell|cmd)\s*:\s*.*",
        "Arbitrary shell command injection in payload",
        "HIGH",
    ),
    (
        r"(curl|wget|nc|netcat|ncat|bash\s+-i|sh\s+-i|cmd\.exe|powershell\.exe)\s+.*(http|ftp|socket|[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)",
        "Network exfiltration / Reverse shell pattern",
        "HIGH",
    ),
    (
        r"(base64\s+-d|base64_decode|eval\(|exec\(|subprocess|system\()",
        "Code execution / Obfuscated payload unpack attempt",
        "MEDIUM",
    ),
    (
        r"<script>|javascript:|alert\(|document\.cookie",
        "Cross-Site Scripting (XSS) payload in agent arguments",
        "MEDIUM",
    ),
]


def normalize_text(text: str) -> str:
    """
    Normalizes string by converting to lowercase, collapsing whitespace,
    and stripping zero-width and invisible unicode characters.
    """
    if not text:
        return ""
    # Remove zero-width characters and unusual whitespace
    cleaned = re.sub(r"[\u200B-\u200D\uFEFF\u0000-\u001F]", " ", text)
    # Replace common leetspeak substitutions
    cleaned = cleaned.lower()
    cleaned = re.sub(r"\s+", " ", cleaned).strip()
    return cleaned


def extract_strings_from_payload(target: str, arguments: Any) -> List[str]:
    """
    Recursively collects all text and string values from target and nested arguments.
    """
    collected: List[str] = []
    if target:
        collected.append(str(target))

    def _traverse(node: Any):
        if isinstance(node, str):
            collected.append(node)
        elif isinstance(node, dict):
            for k, v in node.items():
                collected.append(str(k))
                _traverse(v)
        elif isinstance(node, (list, tuple, set)):
            for item in node:
                _traverse(item)
        elif node is not None:
            collected.append(str(node))

    _traverse(arguments)
    return collected


def detect_prompt_injection(target: str, arguments: Any) -> Tuple[bool, str, Optional[str]]:
    """
    Scans target and arguments for malicious injection signatures.

    Returns:
        (detected: bool, severity: str ("HIGH" | "MEDIUM" | "NONE"), reason: Optional[str])
    """
    extracted_strings = extract_strings_from_payload(target, arguments)

    for raw_str in extracted_strings:
        normalized = normalize_text(raw_str)
        if not normalized:
            continue

        for pattern, reason, severity in SUSPICIOUS_PATTERNS:
            if re.search(pattern, normalized, flags=re.IGNORECASE):
                return True, severity, f"Prompt Injection Detected: {reason} (matched content snippet: '{raw_str[:60]}...')"

    return False, "NONE", None
