import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException, Query, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .database import (
    approve_action,
    clear_all_logs,
    create_audit_log,
    deny_action,
    get_agent_profiles,
    get_audit_logs,
    get_log_by_request_id,
    get_pending_approvals,
    get_security_posture,
    get_system_stats,
    get_threat_intelligence,
    init_db,
)
from .models import (
    AgentProfile,
    AuditLogEntry,
    Decision,
    InterceptResponse,
    PendingApprovalItem,
    ResolutionResponse,
    RiskLevel,
    SecurityPosture,
    StatsResponse,
    ThreatIntelItem,
    ToolCallPayload,
)
from .policy import evaluate_action, GREEN_ACTIONS, AMBER_ACTIONS, RED_ACTIONS

# Initialize Database on startup
init_db()

app = FastAPI(
    title="AgentGuard API",
    description="Autonomous AI Agent Runtime Security Gateway & Action Firewall",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# Enable CORS for local testing and web integration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

FRONTEND_DIR = Path(__file__).resolve().parent.parent / "frontend"


# --------------------------------------------------------------------------
# Gateway Interception Endpoint
# --------------------------------------------------------------------------
@app.post(
    "/api/intercept",
    response_model=InterceptResponse,
    status_code=status.HTTP_200_OK,
    summary="Intercept and evaluate AI agent tool call",
    description="Inspects the incoming agent action, runs prompt injection heuristics, evaluates rule policies, and enforces GREEN/AMBER/RED decisions.",
)
def intercept_tool_call(payload: ToolCallPayload) -> InterceptResponse:
    if not payload.agent or not payload.agent.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Agent identifier cannot be empty",
        )
    if not payload.action or not payload.action.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Action identifier cannot be empty",
        )

    # 1. Run Policy & Injection Engine
    risk_level, decision, reason, approval_required, injection_detected, injection_reason = evaluate_action(
        agent=payload.agent,
        action=payload.action,
        target=payload.target or "",
        arguments=payload.arguments or {},
    )

    request_id = f"req_{uuid.uuid4().hex[:12]}"
    timestamp = datetime.now(timezone.utc).isoformat()

    # 2. Persist in Audit Log Database
    create_audit_log(
        request_id=request_id,
        agent=payload.agent,
        action=payload.action,
        target=payload.target or "",
        arguments=payload.arguments or {},
        risk_level=risk_level,
        decision=decision,
        reason=reason,
        prompt_injection_detected=injection_detected,
        prompt_injection_reason=injection_reason,
        approval_required=approval_required,
        timestamp=timestamp,
    )

    return InterceptResponse(
        request_id=request_id,
        timestamp=timestamp,
        agent=payload.agent,
        action=payload.action,
        target=payload.target or "",
        arguments=payload.arguments or {},
        risk_level=risk_level,
        decision=decision,
        reason=reason,
        approval_required=approval_required,
        prompt_injection_detected=injection_detected,
        prompt_injection_reason=injection_reason,
    )


# --------------------------------------------------------------------------
# Human-in-the-loop Approval Endpoints
# --------------------------------------------------------------------------
@app.get(
    "/api/pending",
    response_model=List[PendingApprovalItem],
    summary="List pending RED actions waiting for human approval",
)
def list_pending_approvals() -> List[PendingApprovalItem]:
    items = get_pending_approvals()
    return [
        PendingApprovalItem(
            id=item["id"],
            request_id=item["request_id"],
            timestamp=item["timestamp"],
            agent=item["agent"],
            action=item["action"],
            target=item["target"],
            arguments=item["arguments"],
            risk_level=item["risk_level"],
            decision=item["decision"],
            reason=item["reason"],
            prompt_injection_detected=item["prompt_injection_detected"],
            prompt_injection_reason=item.get("prompt_injection_reason"),
        )
        for item in items
    ]


@app.post(
    "/api/approve/{request_id}",
    response_model=ResolutionResponse,
    summary="Approve a blocked pending action",
)
def approve_pending_action(request_id: str) -> ResolutionResponse:
    existing = get_log_by_request_id(request_id)
    if not existing:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Request ID '{request_id}' not found",
        )

    res = approve_action(request_id=request_id, approver="SecurityAdmin")
    if not res:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Failed to approve request '{request_id}'",
        )

    if res.get("already_resolved"):
        return ResolutionResponse(
            success=True,
            request_id=request_id,
            decision=Decision(res["log"]["decision"]),
            approved_by=res["log"].get("approved_by") or "SecurityAdmin",
            resolved_at=res["log"].get("resolved_at") or "",
            message=f"Action was already resolved as {res['log']['decision']}",
        )

    return ResolutionResponse(
        success=True,
        request_id=request_id,
        decision=Decision.APPROVED,
        approved_by=res.get("approved_by") or "SecurityAdmin",
        resolved_at=res.get("resolved_at") or "",
        message=f"Action '{res['action']}' approved by human security operator. Permitted for execution.",
    )


@app.post(
    "/api/deny/{request_id}",
    response_model=ResolutionResponse,
    summary="Deny a blocked pending action",
)
def deny_pending_action(request_id: str) -> ResolutionResponse:
    existing = get_log_by_request_id(request_id)
    if not existing:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Request ID '{request_id}' not found",
        )

    res = deny_action(request_id=request_id, approver="SecurityAdmin")
    if not res:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Failed to deny request '{request_id}'",
        )

    if res.get("already_resolved"):
        return ResolutionResponse(
            success=True,
            request_id=request_id,
            decision=Decision(res["log"]["decision"]),
            approved_by=res["log"].get("approved_by") or "SecurityAdmin",
            resolved_at=res["log"].get("resolved_at") or "",
            message=f"Action was already resolved as {res['log']['decision']}",
        )

    return ResolutionResponse(
        success=True,
        request_id=request_id,
        decision=Decision.DENIED,
        approved_by=res.get("approved_by") or "SecurityAdmin",
        resolved_at=res.get("resolved_at") or "",
        message=f"Action '{res['action']}' permanently denied by human security operator. Execution halted.",
    )


# --------------------------------------------------------------------------
# Audit Logs & Analytics
# --------------------------------------------------------------------------
@app.get(
    "/api/logs",
    response_model=List[AuditLogEntry],
    summary="Retrieve audit logs with optional filtering",
)
def get_logs(
    filter: Optional[str] = Query(
        default=None,
        description="Filter by GREEN, AMBER, RED, ALLOW, LOGGED, BLOCKED, APPROVED, DENIED, or PENDING",
    ),
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
) -> List[AuditLogEntry]:
    items = get_audit_logs(filter_type=filter, limit=limit, offset=offset)
    return [
        AuditLogEntry(
            id=item["id"],
            request_id=item["request_id"],
            timestamp=item["timestamp"],
            agent=item["agent"],
            action=item["action"],
            target=item["target"],
            arguments=item["arguments"],
            risk_level=item["risk_level"],
            decision=item["decision"],
            reason=item["reason"],
            prompt_injection_detected=item["prompt_injection_detected"],
            prompt_injection_reason=item.get("prompt_injection_reason"),
            approval_required=item["approval_required"],
            approved_by=item.get("approved_by"),
            resolved_at=item.get("resolved_at"),
        )
        for item in items
    ]


@app.get(
    "/api/agents",
    response_model=List[AgentProfile],
    summary="Get all AI agent profiles and risk scores",
)
def get_agents() -> List[AgentProfile]:
    profiles = get_agent_profiles()
    return [AgentProfile(**p) for p in profiles]


@app.get(
    "/api/threats",
    response_model=List[ThreatIntelItem],
    summary="Get threat intelligence telemetry and categorized incidents",
)
def get_threats() -> List[ThreatIntelItem]:
    threats = get_threat_intelligence()
    return [ThreatIntelItem(**t) for t in threats]


@app.get(
    "/api/posture",
    response_model=SecurityPosture,
    summary="Get detailed security posture breakdown and recommendations",
)
def get_posture() -> SecurityPosture:
    posture = get_security_posture()
    return SecurityPosture(**posture)


@app.get(
    "/api/stats",
    response_model=StatsResponse,
    summary="Get real-time security statistics and security health score",
)
def get_stats() -> StatsResponse:
    stats = get_system_stats()
    return StatsResponse(**stats)


@app.api_route(
    "/api/reset",
    methods=["GET", "POST"],
    summary="Reset database logs for a clean demo run",
)
def reset_logs() -> Dict[str, Any]:
    clear_all_logs()
    return {"status": "success", "message": "All audit logs and pending items reset."}


# --------------------------------------------------------------------------
# Policy Management & Rules
# --------------------------------------------------------------------------
POLICIES_STATE = {
    "pol-green": {
        "id": "pol-green",
        "tier": "GREEN",
        "name": "Safe Read-Only Operations",
        "description": "Permits read queries with zero side effects. Immediately authorized and appended to telemetry.",
        "decision": "ALLOW",
        "enabled": True,
        "actions": sorted(list(GREEN_ACTIONS)),
    },
    "pol-amber": {
        "id": "pol-amber",
        "tier": "AMBER",
        "name": "State Modifications & External Calls",
        "description": "External mutations, outbound messages, and write actions. Allowed with comprehensive audit logging.",
        "decision": "LOGGED",
        "enabled": True,
        "actions": sorted(list(AMBER_ACTIONS)),
    },
    "pol-red": {
        "id": "pol-red",
        "tier": "RED",
        "name": "Destructive Actions & Threat Injections",
        "description": "High-risk tools, shell execution, or detected prompt injections. Paused and routed to Human-in-the-Loop queue.",
        "decision": "BLOCKED",
        "enabled": True,
        "actions": sorted(list(RED_ACTIONS)),
    },
}

SETTINGS_STATE = {
    "strict_injection_defense": True,
    "human_approval_threshold": "HIGH_ONLY",
    "auto_quarantine_untrusted": True,
    "audit_retention_days": 90,
    "gateway_enforcement_mode": "ACTIVE_BLOCKING",
}


@app.get("/api/policies", summary="Retrieve all active policy engine tiers and rules")
def get_policies() -> List[Dict[str, Any]]:
    return list(POLICIES_STATE.values())


@app.post("/api/policies/{policy_id}/toggle", summary="Enable or disable a specific policy tier")
def toggle_policy(policy_id: str) -> Dict[str, Any]:
    if policy_id not in POLICIES_STATE:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Policy ID '{policy_id}' not found",
        )
    POLICIES_STATE[policy_id]["enabled"] = not POLICIES_STATE[policy_id]["enabled"]
    return {
        "id": policy_id,
        "enabled": POLICIES_STATE[policy_id]["enabled"],
        "message": f"Policy '{POLICIES_STATE[policy_id]['name']}' is now {'enabled' if POLICIES_STATE[policy_id]['enabled'] else 'disabled'}.",
    }


@app.post("/api/policies/{policy_id}", summary="Update a policy rule definition")
def update_policy(policy_id: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    if policy_id not in POLICIES_STATE:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Policy ID '{policy_id}' not found",
        )
    name = payload.get("name", "").strip()
    if not name:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Policy name cannot be empty.",
        )
    description = payload.get("description", "").strip()
    if not description:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Policy description cannot be empty.",
        )
    
    POLICIES_STATE[policy_id]["name"] = name
    POLICIES_STATE[policy_id]["description"] = description
    if "enabled" in payload:
        POLICIES_STATE[policy_id]["enabled"] = bool(payload["enabled"])
    return {
        "status": "success",
        "policy": POLICIES_STATE[policy_id],
        "message": "Policy successfully updated.",
    }


# --------------------------------------------------------------------------
# System Health & Diagnostic Endpoints
# --------------------------------------------------------------------------
@app.get("/api/health", summary="Get comprehensive health and latency diagnostics for all components")
def get_health() -> Dict[str, Any]:
    return {
        "status": "HEALTHY",
        "gateway_version": "1.2.0",
        "uptime": "99.98%",
        "active_policies": sum(1 for p in POLICIES_STATE.values() if p["enabled"]),
        "components": [
            {"name": "Runtime Action Interceptor", "status": "OPERATIONAL", "latency_ms": 1.8},
            {"name": "Heuristic Injection Detector", "status": "OPERATIONAL", "latency_ms": 0.4},
            {"name": "Rule Policy Engine", "status": "OPERATIONAL", "latency_ms": 0.2},
            {"name": "SQLite Forensic Store", "status": "OPERATIONAL", "latency_ms": 1.1},
            {"name": "Human-in-the-Loop Queue", "status": "OPERATIONAL", "latency_ms": 0.3},
            {"name": "Agent Intelligence Registry", "status": "OPERATIONAL", "latency_ms": 0.5},
        ],
    }


# --------------------------------------------------------------------------
# System Settings Endpoints
# --------------------------------------------------------------------------
@app.get("/api/settings", summary="Retrieve gateway configuration settings")
def get_settings() -> Dict[str, Any]:
    return SETTINGS_STATE


@app.post("/api/settings", summary="Update gateway configuration settings")
def update_settings(payload: Dict[str, Any]) -> Dict[str, Any]:
    valid_modes = {"ACTIVE_BLOCKING", "AUDIT_ONLY", "LEARNING"}
    valid_thresholds = {"ALL", "HIGH_ONLY", "CRITICAL_ONLY"}

    if "gateway_enforcement_mode" in payload:
        if payload["gateway_enforcement_mode"] not in valid_modes:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Invalid enforcement mode. Must be one of {valid_modes}",
            )
        SETTINGS_STATE["gateway_enforcement_mode"] = payload["gateway_enforcement_mode"]

    if "human_approval_threshold" in payload:
        if payload["human_approval_threshold"] not in valid_thresholds:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Invalid approval threshold. Must be one of {valid_thresholds}",
            )
        SETTINGS_STATE["human_approval_threshold"] = payload["human_approval_threshold"]

    if "strict_injection_defense" in payload:
        SETTINGS_STATE["strict_injection_defense"] = bool(payload["strict_injection_defense"])

    if "auto_quarantine_untrusted" in payload:
        SETTINGS_STATE["auto_quarantine_untrusted"] = bool(payload["auto_quarantine_untrusted"])

    if "audit_retention_days" in payload:
        try:
            days = int(payload["audit_retention_days"])
            if days < 1 or days > 365:
                raise ValueError()
            SETTINGS_STATE["audit_retention_days"] = days
        except (ValueError, TypeError):
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="Audit retention days must be an integer between 1 and 365.",
            )

    return {
        "status": "success",
        "settings": SETTINGS_STATE,
        "message": "Gateway settings saved and applied successfully.",
    }


# --------------------------------------------------------------------------
# Frontend Static Files & SPA Routing
# --------------------------------------------------------------------------
if FRONTEND_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")

    @app.get("/", include_in_schema=False)
    def serve_index():
        index_file = FRONTEND_DIR / "index.html"
        if index_file.exists():
            return FileResponse(index_file)
        return JSONResponse({"message": "AgentGuard API is running. Visit /docs for API documentation."})
