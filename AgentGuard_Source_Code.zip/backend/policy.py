import re
from typing import Any, Dict, Optional, Tuple
from .models import Decision, RiskLevel
from .detector import detect_prompt_injection


# Safe read-only actions: ALLOW
GREEN_ACTIONS = {
    "read_file",
    "search_web",
    "get_weather",
    "list_files",
    "calculate",
    "get_time",
    "fetch_url",
    "read_document",
    "view_image",
    "query_status",
    "get_user_profile",
    "list_directory",
}

# Sensitive or state-modifying actions: LOGGED
AMBER_ACTIONS = {
    "send_email",
    "create_file",
    "update_record",
    "api_request",
    "modify_file",
    "write_file",
    "post_message",
    "insert_record",
    "edit_document",
    "upload_file",
    "download_file",
    "send_sms",
    "update_user",
}

# High-risk / Destructive operations: BLOCKED (Require Human Approval)
RED_ACTIONS = {
    "delete_file",
    "delete_database",
    "drop_database_table",
    "execute_shell",
    "shutdown_server",
    "transfer_money",
    "delete_user",
    "chmod_system",
    "format_disk",
    "kill_process",
    "modify_permissions",
    "reboot_system",
    "exec_code",
    "drop_table",
    "truncate_table",
    "wipe_data",
    "purge_logs",
    "flush_cache_all",
    "run_terminal_command",
}

# Critical sensitive file targets that trigger automatic RED escalation
SENSITIVE_TARGET_PATTERNS = [
    r"(\.env|credentials\.json|id_rsa|private_key\.pem|master\.key|secrets\.yaml)",
    r"(/etc/passwd|/etc/shadow|C:\\Windows\\System32|/root)",
    r"(users|accounts|passwords|auth_tokens|api_keys)\.db",
]


def check_sensitive_target(target: str) -> bool:
    if not target:
        return False
    for pat in SENSITIVE_TARGET_PATTERNS:
        if re.search(pat, target, flags=re.IGNORECASE):
            return True
    return False


def evaluate_action(
    agent: str,
    action: str,
    target: str = "",
    arguments: Optional[Dict[str, Any]] = None,
) -> Tuple[RiskLevel, Decision, str, bool, bool, Optional[str]]:
    """
    Evaluates tool-call risk and determines enforcement decision.

    Returns:
        (risk_level, decision, reason, approval_required, prompt_injection_detected, prompt_injection_reason)
    """
    args = arguments or {}
    action_clean = (action or "").strip().lower()

    # Step 1: Prompt Injection Analysis
    injection_detected, injection_severity, injection_reason = detect_prompt_injection(target, args)

    if injection_detected and injection_severity == "HIGH":
        return (
            RiskLevel.RED,
            Decision.BLOCKED,
            f"High-risk prompt injection detected in payload. {injection_reason}",
            True,
            True,
            injection_reason,
        )

    # Step 2: Target-level sensitivity analysis
    is_sensitive_target = check_sensitive_target(target)
    if is_sensitive_target and action_clean in GREEN_ACTIONS:
        return (
            RiskLevel.RED,
            Decision.BLOCKED,
            f"Access to sensitive target '{target}' blocked for security review.",
            True,
            injection_detected,
            injection_reason,
        )

    # Step 3: Action-level policy evaluation
    if action_clean in RED_ACTIONS:
        reason = f"Destructive or high-risk operation '{action}' intercepted. Human authorization mandatory."
        if injection_detected:
            reason += f" [{injection_reason}]"
        return (
            RiskLevel.RED,
            Decision.BLOCKED,
            reason,
            True,
            injection_detected,
            injection_reason,
        )

    if action_clean in AMBER_ACTIONS:
        if injection_detected:
            return (
                RiskLevel.RED,
                Decision.BLOCKED,
                f"Potentially sensitive action '{action}' escalated to RED due to prompt injection: {injection_reason}",
                True,
                True,
                injection_reason,
            )
        return (
            RiskLevel.AMBER,
            Decision.LOGGED,
            f"Potentially sensitive state-modifying action '{action}' logged for auditing.",
            False,
            False,
            None,
        )

    if action_clean in GREEN_ACTIONS:
        if injection_detected:
            return (
                RiskLevel.RED,
                Decision.BLOCKED,
                f"Read action '{action}' blocked due to prompt injection attempt: {injection_reason}",
                True,
                True,
                injection_reason,
            )
        return (
            RiskLevel.GREEN,
            Decision.ALLOW,
            f"Safe read-only action '{action}' verified and permitted.",
            False,
            False,
            None,
        )

    # Step 4: Unknown action fallback
    if any(keyword in action_clean for keyword in ["delete", "drop", "kill", "rm", "destroy", "format", "shutdown", "exec"]):
        return (
            RiskLevel.RED,
            Decision.BLOCKED,
            f"Unregistered action '{action}' containing dangerous keywords blocked for approval.",
            True,
            injection_detected,
            injection_reason,
        )

    # Default unknown action -> Logged with caution (AMBER)
    return (
        RiskLevel.AMBER,
        Decision.LOGGED,
        f"Unregistered action '{action}' evaluated with cautious logging policy.",
        False,
        injection_detected,
        injection_reason,
    )
