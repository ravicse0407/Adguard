from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


class RiskLevel(str, Enum):
    GREEN = "GREEN"
    AMBER = "AMBER"
    RED = "RED"


class Decision(str, Enum):
    ALLOW = "ALLOW"
    LOGGED = "LOGGED"
    BLOCKED = "BLOCKED"
    APPROVED = "APPROVED"
    DENIED = "DENIED"


class ToolCallPayload(BaseModel):
    agent: str = Field(..., min_length=1, description="Name or ID of the AI agent")
    action: str = Field(..., min_length=1, description="Tool or function being called")
    target: Optional[str] = Field(default="", description="Target resource, file, database, or endpoint")
    arguments: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Key-value arguments for tool call")


class InterceptResponse(BaseModel):
    request_id: str
    timestamp: str
    agent: str
    action: str
    target: str
    arguments: Dict[str, Any]
    risk_level: RiskLevel
    decision: Decision
    reason: str
    approval_required: bool
    prompt_injection_detected: bool
    prompt_injection_reason: Optional[str] = None


class AuditLogEntry(BaseModel):
    id: int
    request_id: str
    timestamp: str
    agent: str
    action: str
    target: str
    arguments: Dict[str, Any]
    risk_level: str
    decision: str
    reason: str
    prompt_injection_detected: bool
    prompt_injection_reason: Optional[str] = None
    approval_required: bool
    approved_by: Optional[str] = None
    resolved_at: Optional[str] = None


class PendingApprovalItem(BaseModel):
    id: int
    request_id: str
    timestamp: str
    agent: str
    action: str
    target: str
    arguments: Dict[str, Any]
    risk_level: str
    decision: str
    reason: str
    prompt_injection_detected: bool
    prompt_injection_reason: Optional[str] = None


class ResolutionResponse(BaseModel):
    success: bool
    request_id: str
    decision: Decision
    approved_by: str
    resolved_at: str
    message: str


class AgentProfile(BaseModel):
    name: str
    risk_tier: str  # LOW, MEDIUM, HIGH, CRITICAL
    risk_score: int  # 0-100
    trust_level: str  # HIGH, MODERATE, RESTRICTED, UNTRUSTED
    total_actions: int
    allowed_count: int
    blocked_count: int
    pending_count: int
    allowed_tools: List[str]
    blocked_tools: List[str]
    recent_actions: List[Dict[str, Any]]
    policy_violations: int


class ThreatIntelItem(BaseModel):
    id: str
    title: str
    category: str
    severity: str  # CRITICAL, HIGH, MEDIUM, LOW
    count: int
    trend: str
    last_detected: Optional[str] = None
    description: str


class SecurityPosture(BaseModel):
    overall_score: int
    runtime_protection: int
    prompt_defense: int
    tool_security: int
    policy_coverage: int
    audit_integrity: int
    recommendations_count: int
    recommendations: List[Dict[str, Any]]


class StatsResponse(BaseModel):
    total_actions: int
    approved_count: int
    logged_count: int
    blocked_count: int
    pending_count: int
    denied_count: int
    prompt_injections_detected: int
    security_score: int
    system_status: str
    agents_protected: int = 4
    risk_distribution: Dict[str, int] = Field(default_factory=lambda: {"LOW": 68, "MEDIUM": 21, "HIGH": 8, "CRITICAL": 3})
    threat_intel_counts: Dict[str, int] = Field(default_factory=dict)
